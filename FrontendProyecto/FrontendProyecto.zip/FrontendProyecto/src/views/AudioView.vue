<template>
  <div>
    <AudioList />
  </div>
</template>

<script>
import AudioList from '../components/AudioList.vue'

export default {
  components: {
    AudioList,
  },
}
</script>
