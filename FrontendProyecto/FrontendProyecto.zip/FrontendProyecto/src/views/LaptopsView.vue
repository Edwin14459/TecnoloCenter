<template>
  <div>
    <LaptopList />
  </div>
</template>

<script>
import LaptopList from '../components/LaptopList.vue'

export default {
  components: {
    LaptopList,
  },
}
</script>
