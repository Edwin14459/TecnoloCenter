<template>
  <div>
    <SmartphoneList />
  </div>
</template>

<script>
import SmartphoneList from '../components/SmartphoneList.vue'

export default {
  components: {
    SmartphoneList,
  },
}
</script>
