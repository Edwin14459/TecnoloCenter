<template>
  <AdminList />
</template>

<script>
import AdminList from '../components/AdminList.vue'

export default {
  components: {
    AdminList
  }
}
</script>
