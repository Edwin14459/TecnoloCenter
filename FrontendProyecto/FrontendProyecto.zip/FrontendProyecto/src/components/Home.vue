<template>
  <div class="container text-center py-5">
    <div class="bg-light p-5 rounded shadow">
      <h1 class="display-4 fw-bold mb-3 text-primary">Bienvenidos a <span class="text-dark">TecnolCenter</span></h1>
      <p class="lead mb-4 text-secondary">
        Plataforma integral para la gestión de dispositivos tecnológicos
      </p>
      <hr class="my-4" />
      <p class="text-muted">
        Optimiza, controla y supervisa todos tus equipos desde un solo lugar.
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'home',
}
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: auto;
}

.bg-light {
  background-color: #f8f9fa;
}

.text-primary {
  color: #0d6efd;
}

.shadow {
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
}
</style>
