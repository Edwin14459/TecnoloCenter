<template>
  <div>
    <TabletList />
  </div>
</template>

<script>
import TabletList from '../components/TabletList.vue'

export default {
  components: {
    TabletList,
  },
}
</script>
