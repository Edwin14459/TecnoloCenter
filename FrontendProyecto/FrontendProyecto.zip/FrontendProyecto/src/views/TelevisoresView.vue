<template>
  <div>
    <TelevisorList />
  </div>
</template>

<script>
import TelevisorList from '../components/TelevisorList.vue'

export default {
  components: {
    TelevisorList,
  },
}
</script>
