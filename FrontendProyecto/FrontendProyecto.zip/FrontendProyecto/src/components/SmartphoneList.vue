<template>
  <div class="container mt-4">
    <h4 class="mb-3 text-primary">Gestión de Smartphones</h4>

    <!-- Formulario siempre visible -->
    <SmartphoneForm
      :smartphoneEdit="smartphoneEditado"
      @form-enviado="refrescar"
      @cancelar-edicion="cancelarEdicion"
    />

    <hr class="my-4" />

    <h5 class="mb-3 text-danger text-center">Lista de Smartphones</h5>

    <!-- Botón para descargar registros en PDF -->
    <div class="d-flex justify-content-end mb-3">
      <button class="btn btn-outline-success" @click="descargarPDF">
        <i class="bi bi-download me-2"></i> Descargar Registros en PDF
      </button>
    </div>

    <div class="table-responsive">
      <table class="table table-hover table-bordered shadow-sm">
        <thead class="table-info">
          <tr>
            <th class="text-center align-middle">Marca</th>
            <th class="text-center align-middle">Modelo</th>
            <th class="text-center align-middle">RAM (GB)</th>
            <th class="text-center align-middle">Almacenamiento (GB)</th>
            <th class="text-center align-middle">Especificaciones</th>
            <th class="text-center align-middle">Precio</th>
            <th class="text-center align-middle">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="smartphone in smartphones" :key="smartphone.id" class="align-middle">
            <td class="text-center">{{ smartphone.marca }}</td>
            <td class="text-center">{{ smartphone.modelo }}</td>
            <td class="text-center">{{ smartphone.ram }}</td>
            <td class="text-center">{{ smartphone.almacenamiento }}</td>
            <td class="text-center text-truncate" style="max-width: 200px;" :title="smartphone.especificaciones">
              {{ smartphone.especificaciones }}
            </td>
            <td class="text-center">${{ smartphone.precio.toLocaleString() }}</td>
            <td class="text-center">
              <div class="d-flex justify-content-center">
                <button 
                  class="btn btn-warning btn-sm me-2" 
                  @click="editarSmartphone(smartphone)"
                  title="Editar"
                >
                  <i class="bi bi-pencil-square"></i>
                </button>
                <button 
                  class="btn btn-danger btn-sm" 
                  @click="eliminarSmartphone(smartphone.id)"
                  title="Eliminar"
                >
                  <i class="bi bi-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import SmartphoneForm from './SmartphoneForm.vue'
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'

const smartphones = ref([])
const smartphoneEditado = ref(null) // null significa modo insertar

const cargarSmartphones = async () => {
  try {
    const res = await axios.get('/smartphone/traer_smartphone') // Asegúrate que esta sea la ruta correcta
    smartphones.value = res.data
  } catch (error) {
    console.error('Error al cargar smartphones:', error)
  }
}

const editarSmartphone = (smartphone) => {
  smartphoneEditado.value = { ...smartphone }
}

const eliminarSmartphone = async (id) => {
  if (confirm('¿Estás seguro de eliminar este smartphone?')) {
    try {
      await axios.delete(`/smartphone/eliminar/${id}`)
      cargarSmartphones()
    } catch (error) {
      console.error('Error al eliminar smartphone:', error)
    }
  }
}

const cancelarEdicion = () => {
  smartphoneEditado.value = null
}

const refrescar = () => {
  cargarSmartphones()
  cancelarEdicion()
}

const descargarPDF = () => {
  const doc = new jsPDF()

  doc.setFontSize(16)
  doc.text('Listado de Smartphones', 14, 15)

  autoTable(doc, {
    startY: 20,
    head: [['Marca', 'Modelo', 'RAM (GB)', 'Almacenamiento (GB)', 'Especificaciones', 'Precio']],
    body: smartphones.value.map(s => [
      s.marca,
      s.modelo,
      s.ram,
      s.almacenamiento,
      s.especificaciones,
      `$${s.precio.toLocaleString()}`
    ]),
    styles: { fontSize: 10 },
    headStyles: { fillColor: [0, 123, 255] },
  })

  doc.save('smartphones.pdf')
}

onMounted(cargarSmartphones)
</script>
